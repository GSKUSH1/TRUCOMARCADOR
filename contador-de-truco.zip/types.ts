
export type Team = 'nos' | 'eles';

export type Scores = Record<Team, number>;

export type Victories = Record<Team, number>;
