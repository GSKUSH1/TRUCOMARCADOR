
import React from 'react';
import { Team } from '../types';
import { SCORE_OPTIONS } from '../constants';

interface TeamPanelProps {
  teamId: Team;
  teamName: string;
  score: number;
  onAddPoints: (team: Team, points: number) => void;
  disabled: boolean;
}

const TeamPanel: React.FC<TeamPanelProps> = ({ teamId, teamName, score, onAddPoints, disabled }) => {
  const accentColor = teamId === 'nos' ? 'cyan' : 'amber';
  
  return (
    <div className={`bg-slate-800/50 backdrop-blur-sm p-6 rounded-2xl shadow-lg border border-slate-700 flex flex-col items-center ring-1 ring-white/10`}>
      <h2 className={`text-4xl font-bold text-transparent bg-clip-text bg-gradient-to-b from-${accentColor}-300 to-${accentColor}-500 mb-4`}>
        {teamName}
      </h2>
      <div className="w-full text-center mb-6">
        <span className="text-8xl md:text-9xl font-black text-slate-100 tracking-tighter">
          {score.toString().padStart(2, '0')}
        </span>
      </div>
      <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 w-full">
        {SCORE_OPTIONS.map(({ label, value }) => (
          <button
            key={value}
            onClick={() => onAddPoints(teamId, value)}
            disabled={disabled}
            className={`col-span-1 ${value > 3 ? 'sm:col-span-3' : ''} bg-slate-700/50 text-slate-200 font-semibold py-3 px-2 rounded-lg transition-all duration-200 ease-in-out
                       hover:bg-${accentColor}-500 hover:text-white hover:shadow-lg hover:shadow-${accentColor}-500/20
                       disabled:bg-slate-800 disabled:text-slate-600 disabled:cursor-not-allowed disabled:shadow-none transform hover:scale-105 active:scale-100`}
          >
            {label}
          </button>
        ))}
      </div>
    </div>
  );
};

export default TeamPanel;
