
import React from 'react';
import { TrophyIcon } from './icons/TrophyIcon';

interface WinnerModalProps {
  winnerName: string;
  onNewMatch: () => void;
}

const WinnerModal: React.FC<WinnerModalProps> = ({ winnerName, onNewMatch }) => {
  return (
    <div className="fixed inset-0 bg-black/70 backdrop-blur-sm flex items-center justify-center z-50 animate-fade-in">
      <div className="bg-slate-800 rounded-2xl shadow-2xl p-8 m-4 text-center border border-slate-600 animate-slide-up">
        <div className="flex justify-center mb-4">
            <TrophyIcon />
        </div>
        <h2 className="text-2xl font-bold text-slate-300">A partida acabou!</h2>
        <p className="text-4xl font-extrabold text-transparent bg-clip-text bg-gradient-to-r from-amber-300 to-yellow-400 my-4">
          {winnerName} venceu!
        </p>
        <button
          onClick={onNewMatch}
          className="mt-6 bg-cyan-500 hover:bg-cyan-400 text-cyan-900 font-bold py-3 px-8 rounded-lg text-lg transition-all duration-300 transform hover:scale-105 focus:outline-none focus:ring-4 focus:ring-cyan-500/50"
        >
          Jogar Nova Partida
        </button>
      </div>
      <style>{`
        @keyframes fade-in {
          from { opacity: 0; }
          to { opacity: 1; }
        }
        @keyframes slide-up {
          from { transform: translateY(20px); opacity: 0; }
          to { transform: translateY(0); opacity: 1; }
        }
        .animate-fade-in { animation: fade-in 0.3s ease-out forwards; }
        .animate-slide-up { animation: slide-up 0.4s ease-out 0.1s forwards; }
      `}</style>
    </div>
  );
};

export default WinnerModal;
