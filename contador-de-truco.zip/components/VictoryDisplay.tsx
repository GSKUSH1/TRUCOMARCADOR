
import React from 'react';
import { Victories } from '../types';
import { TEAMS } from '../constants';

interface VictoryDisplayProps {
  victories: Victories;
}

const VictoryDisplay: React.FC<VictoryDisplayProps> = ({ victories }) => {
  return (
    <div className="bg-slate-800/50 backdrop-blur-sm p-4 rounded-xl shadow-md border border-slate-700 text-center ring-1 ring-white/10">
      <h3 className="text-sm font-medium text-slate-400 uppercase tracking-wider mb-2">Placar de Vitórias</h3>
      <div className="flex items-center justify-center space-x-4">
        <div className="text-right">
            <span className="text-xl font-bold text-cyan-400">{TEAMS.NOS}</span>
        </div>
        <div className="text-4xl font-black text-slate-200">
          <span>{victories.nos}</span>
          <span className="text-slate-500 mx-2">x</span>
          <span>{victories.eles}</span>
        </div>
        <div className="text-left">
            <span className="text-xl font-bold text-amber-400">{TEAMS.ELES}</span>
        </div>
      </div>
    </div>
  );
};

export default VictoryDisplay;
