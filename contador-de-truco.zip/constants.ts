
export const MAX_SCORE = 12;

export const TEAMS = {
  NOS: 'Nós',
  ELES: 'Eles',
};

export const SCORE_OPTIONS = [
  { label: '+1 Tento', value: 1 },
  { label: 'Truco (+3)', value: 3 },
  { label: 'Seis (+6)', value: 6 },
  { label: 'Nove (+9)', value: 9 },
  { label: 'Doze (+12)', value: 12 },
];
